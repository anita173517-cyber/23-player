package com.harindra.iptvpro.vod

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.media3.ui.PlayerView
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.harindra.iptvpro.ContentSourceType
import com.harindra.iptvpro.ProfileStore
import com.harindra.iptvpro.R
import org.videolan.libvlc.util.VLCVideoLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * RAM PLAYER v22.0 ULTIMATE — Completely Rebuilt Cinematic VOD Player Activity.
 *
 * Powered 100% by [LibVlcVodPlayerEngine] (VideoLAN LibVLC 3.6.5) via [VodPlayerEngine].
 * Strictly independent from Live TV (`PlayerActivity` Media3 ExoPlayer remains 100% untouched).
 */
class VodPlayerActivity : AppCompatActivity() {

    private lateinit var vlcVideoLayout: VLCVideoLayout
    private lateinit var fallbackPlayerView: PlayerView
    private lateinit var nightDimOverlay: View
    private lateinit var colorTintOverlay: View
    private lateinit var loadingContainer: View
    private lateinit var tvLoadingStatus: TextView
    private lateinit var seekPreviewPill: View
    private lateinit var tvSeekDelta: TextView
    private lateinit var tvSeekTargetTime: TextView
    private lateinit var tvNerdStatsHud: TextView
    private lateinit var btnSkipIntro: Button
    private lateinit var btnUnlockScreen: Button

    private lateinit var controlsContainer: View
    private lateinit var btnBack: Button
    private lateinit var tvTitle: TextView
    private lateinit var tvSubtitleMeta: TextView
    private lateinit var tvStatusBadge: TextView
    private lateinit var tvClock: TextView

    private lateinit var btnRewind: Button
    private lateinit var btnPlayPause: Button
    private lateinit var btnForward: Button

    private lateinit var seekBar: SeekBar
    private lateinit var tvCurrentTime: TextView
    private lateinit var tvRemainingTime: TextView
    private lateinit var tvTotalDuration: TextView

    private lateinit var btnPrevEpisode: Button
    private lateinit var btnNextEpisode: Button
    private lateinit var btnEpisodes: Button
    private lateinit var btnAudio: Button
    private lateinit var btnSubtitles: Button
    private lateinit var btnVideoSettings: Button
    private lateinit var btnSpeed: Button
    private lateinit var btnProTools: Button
    private lateinit var btnSettings: Button

    private lateinit var autoNextCard: View
    private lateinit var tvAutoNextBadge: TextView
    private lateinit var tvAutoNextTitle: TextView
    private lateinit var pbAutoNextCountdown: ProgressBar
    private lateinit var btnAutoNextPlayNow: Button
    private lateinit var btnAutoNextCancel: Button

    private lateinit var errorOverlay: View
    private lateinit var tvErrorTitle: TextView
    private lateinit var tvErrorMessage: TextView
    private lateinit var btnErrorRetry: Button
    private lateinit var btnErrorBack: Button

    private lateinit var vodPrefs: VodPreferencesStore
    private lateinit var profileStore: ProfileStore
    private lateinit var progressStore: VodProgressStore
    private lateinit var engineCoordinator: VodEngineCoordinator
    private lateinit var activeEngine: VodPlayerEngine
    private lateinit var diagnosticsEngine: VodDiagnosticsEngine
    private lateinit var adaptiveBufferEngine: VodAdaptiveBufferEngine
    private var activeSessionToken: Long = 0L
    private var lastFocusedViewBeforeModal: View? = null
    private lateinit var audioController: VodAudioController
    private lateinit var recoveryController: VodBufferingAndRecoveryController
    private lateinit var seekController: VodSeekController
    private lateinit var autoNextController: VodAutoNextController
    private lateinit var remoteController: VodRemoteControlController
    private lateinit var proController: VodProFeaturesController

    private var payload: VodLaunchPayload? = null
    private var currentEpisode: VodEpisodeNavItem? = null
    private var currentStreamUrl: String = ""
    private var currentContentId: String = ""
    private var currentTitle: String = ""
    private var activeDialog: AlertDialog? = null
    private var pendingAutoNextEpisode: VodEpisodeNavItem? = null
    private var autoNextRemainingSec: Int = 0
    private var autoNextTotalSec: Int = 10
    private var controlsVisible: Boolean = true
    private var userDraggingSeekBar: Boolean = false
    private var preferredTracksApplied: Boolean = false

    private val uiHandler = Handler(Looper.getMainLooper())
    private val clockFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())

    private val hideControlsRunnable = Runnable {
        if (controlsVisible && activeDialog?.isShowing != true && !userDraggingSeekBar && errorOverlay.visibility != View.VISIBLE) {
            setControlsVisible(false)
        }
    }

    private val hideSeekPreviewRunnable = Runnable {
        seekPreviewPill.visibility = View.GONE
    }

    private val progressTickRunnable = object : Runnable {
        override fun run() {
            updateTimelineFromEngine()
            updateProFeaturesTick()
            checkAutoNextIfEligible()
            tvClock.text = clockFormat.format(Date())
            uiHandler.postDelayed(this, 500L)
        }
    }

    private val periodicSaveRunnable = object : Runnable {
        override fun run() {
            saveCurrentPlaybackProgress()
            uiHandler.postDelayed(this, 10_000L)
        }
    }

    private val autoNextTickRunnable = object : Runnable {
        override fun run() {
            val nextEp = pendingAutoNextEpisode ?: return
            if (autoNextCard.visibility != View.VISIBLE) return
            if (autoNextRemainingSec <= 0) {
                hideAutoNextCard()
                switchToEpisode(nextEp, resumePositionMs = 0L)
                return
            }
            tvAutoNextBadge.text = "UP NEXT IN ${autoNextRemainingSec}s"
            val pct = ((autoNextRemainingSec * 100) / autoNextTotalSec.coerceAtLeast(1)).coerceIn(0, 100)
            pbAutoNextCountdown.progress = pct
            autoNextRemainingSec--
            uiHandler.postDelayed(this, 1_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_vod_player)
        enableImmersiveFullscreen()

        val parsed = VodPlayerLauncher.parsePayload(intent)
        if (parsed == null) {
            Toast.makeText(this, "Invalid VOD item", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        payload = parsed

        vodPrefs = VodPreferencesStore(this)
        profileStore = ProfileStore(this)
        progressStore = VodProgressStore(ProfileStoreVodProgressAdapter(profileStore))
        diagnosticsEngine = VodDiagnosticsEngine()
        adaptiveBufferEngine = VodAdaptiveBufferEngine()
        engineCoordinator = VodEngineCoordinator(
            primaryEngineFactory = { LibVlcVodPlayerEngine(this) },
            fallbackEngineFactory = { Media3FallbackVodEngine(this, vodPrefs) }
        )
        audioController = VodAudioController(this, vodPrefs)
        recoveryController = VodBufferingAndRecoveryController(maxTransientRetries = 3)
        seekController = VodSeekController(vodPrefs.getDefaultSeekInterval())
        autoNextController = VodAutoNextController(parsed.episodes)
        remoteController = VodRemoteControlController()
        proController = VodProFeaturesController()

        bindViews()
        setupFocusContrastListeners()
        setupListeners()
        applySavedUiPreferences()
        startPayloadPlayback(parsed)
    }

    private fun bindViews() {
        vlcVideoLayout = findViewById(R.id.vlcVideoLayout)
        fallbackPlayerView = findViewById(R.id.vodFallbackPlayerView)
        nightDimOverlay = findViewById(R.id.vodNightDimOverlay)
        colorTintOverlay = findViewById(R.id.vodColorTintOverlay)
        loadingContainer = findViewById(R.id.vodLoadingContainer)
        tvLoadingStatus = findViewById(R.id.tvVodLoadingStatus)
        seekPreviewPill = findViewById(R.id.vodSeekPreviewPill)
        tvSeekDelta = findViewById(R.id.tvVodSeekDelta)
        tvSeekTargetTime = findViewById(R.id.tvVodSeekTargetTime)
        tvNerdStatsHud = findViewById(R.id.tvVodNerdStatsHud)
        btnSkipIntro = findViewById(R.id.btnVodSkipIntro)
        btnUnlockScreen = findViewById(R.id.btnVodUnlockScreen)

        controlsContainer = findViewById(R.id.vodControlsContainer)
        btnBack = findViewById(R.id.btnVodBack)
        tvTitle = findViewById(R.id.tvVodTitle)
        tvSubtitleMeta = findViewById(R.id.tvVodSubtitleMeta)
        tvStatusBadge = findViewById(R.id.tvVodPlaybackStatusBadge)
        tvClock = findViewById(R.id.tvVodClock)

        btnRewind = findViewById(R.id.btnVodRewind)
        btnPlayPause = findViewById(R.id.btnVodPlayPause)
        btnForward = findViewById(R.id.btnVodForward)

        seekBar = findViewById(R.id.vodSeekBar)
        tvCurrentTime = findViewById(R.id.tvVodCurrentTime)
        tvRemainingTime = findViewById(R.id.tvVodRemainingTime)
        tvTotalDuration = findViewById(R.id.tvVodTotalDuration)

        btnPrevEpisode = findViewById(R.id.btnVodPrevEpisode)
        btnNextEpisode = findViewById(R.id.btnVodNextEpisode)
        btnEpisodes = findViewById(R.id.btnVodEpisodes)
        btnAudio = findViewById(R.id.btnVodAudio)
        btnSubtitles = findViewById(R.id.btnVodSubtitles)
        btnVideoSettings = findViewById(R.id.btnVodVideoSettings)
        btnSpeed = findViewById(R.id.btnVodSpeed)
        btnProTools = findViewById(R.id.btnVodProTools)
        btnSettings = findViewById(R.id.btnVodSettings)

        autoNextCard = findViewById(R.id.vodAutoNextCard)
        tvAutoNextBadge = findViewById(R.id.tvVodAutoNextBadge)
        tvAutoNextTitle = findViewById(R.id.tvVodAutoNextTitle)
        pbAutoNextCountdown = findViewById(R.id.pbVodAutoNextCountdown)
        btnAutoNextPlayNow = findViewById(R.id.btnVodAutoNextPlayNow)
        btnAutoNextCancel = findViewById(R.id.btnVodAutoNextCancel)

        errorOverlay = findViewById(R.id.vodErrorOverlay)
        tvErrorTitle = findViewById(R.id.tvVodErrorTitle)
        tvErrorMessage = findViewById(R.id.tvVodErrorMessage)
        btnErrorRetry = findViewById(R.id.btnVodErrorRetry)
        btnErrorBack = findViewById(R.id.btnVodErrorBack)
    }

    /**
     * Switches button text to crisp dark obsidian when focused on the white TV focus capsule,
     * and back to clean light silver when unfocused — crisp Apple TV+ / Netflix readability.
     */
    private fun setupFocusContrastListeners() {
        val allBtns = listOf(
            btnBack, btnRewind, btnPlayPause, btnForward,
            btnPrevEpisode, btnNextEpisode, btnEpisodes,
            btnAudio, btnSubtitles, btnVideoSettings, btnSpeed,
            btnProTools, btnSettings, btnSkipIntro, btnUnlockScreen,
            btnAutoNextPlayNow, btnAutoNextCancel, btnErrorRetry, btnErrorBack
        )
        for (btn in allBtns) {
            btn.setOnFocusChangeListener { v, hasFocus ->
                (v as? Button)?.setTextColor(if (hasFocus) Color.parseColor("#09090B") else Color.parseColor("#F4F4F5"))
                v.scaleX = if (hasFocus) 1.05f else 1.0f
                v.scaleY = if (hasFocus) 1.05f else 1.0f
            }
        }
    }

    private fun setupListeners() {
        btnBack.setOnClickListener { exitToDetails() }
        btnSkipIntro.setOnClickListener {
            val dur = activeEngine.getDurationMs()
            val target = proController.computeSkipIntroTarget(activeEngine.getPositionMs(), dur)
            activeEngine.seekTo(target)
            btnSkipIntro.visibility = View.GONE
            showFeedbackPill("Skip Intro +85s", "${VodTimeFormatter.formatMs(target)} / ${VodTimeFormatter.formatMs(dur)}")
        }
        btnUnlockScreen.setOnClickListener {
            proController.unlockScreen()
            btnUnlockScreen.visibility = View.GONE
            setControlsVisible(true)
            Toast.makeText(this, "Controls Unlocked", Toast.LENGTH_SHORT).show()
        }

        btnPlayPause.setOnClickListener {
            togglePlayPause()
            scheduleControlsAutoHide()
        }
        btnRewind.setOnClickListener {
            performStepSeek(isForward = false)
            scheduleControlsAutoHide()
        }
        btnForward.setOnClickListener {
            performStepSeek(isForward = true)
            scheduleControlsAutoHide()
        }
        btnPrevEpisode.setOnClickListener {
            val prev = autoNextController.findPreviousEpisode(currentContentId)
            if (prev != null) switchToEpisode(prev, 0L)
            else Toast.makeText(this, "First episode", Toast.LENGTH_SHORT).show()
        }
        btnNextEpisode.setOnClickListener {
            val next = autoNextController.findNextEpisode(currentContentId)
            if (next != null) switchToEpisode(next, 0L)
            else Toast.makeText(this, "No next episode", Toast.LENGTH_SHORT).show()
        }
        btnEpisodes.setOnClickListener { showEpisodesDrawerDialog() }
        btnAudio.setOnClickListener { showAudioPanelDialog() }
        btnSubtitles.setOnClickListener { showSubtitlePanelDialog() }
        btnVideoSettings.setOnClickListener { showVideoSettingsDialog() }
        btnSpeed.setOnClickListener { showSpeedSelectorDialog() }
        btnProTools.setOnClickListener { showCinemaToolsDialog() }
        btnSettings.setOnClickListener { showVodSettingsDialog() }

        btnAutoNextPlayNow.setOnClickListener {
            val nextEp = pendingAutoNextEpisode
            hideAutoNextCard()
            if (nextEp != null) switchToEpisode(nextEp, 0L)
        }
        btnAutoNextCancel.setOnClickListener {
            autoNextController.cancelForEpisode(currentContentId)
            hideAutoNextCard()
        }

        btnErrorRetry.setOnClickListener {
            recoveryController.resetForNewMedia()
            errorOverlay.visibility = View.GONE
            val resumePos = activeEngine.getPositionMs().coerceAtLeast(payload?.resumePositionMs ?: 0L)
            startMediaStream(currentStreamUrl, resumePos)
        }
        btnErrorBack.setOnClickListener { exitToDetails() }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val dur = activeEngine.getDurationMs()
                if (dur > 0L) {
                    val target = (dur * progress.toLong()) / 10_000L
                    tvCurrentTime.text = VodTimeFormatter.formatMs(target)
                    showFeedbackPill(VodTimeFormatter.formatMs(target), "${VodTimeFormatter.formatMs(target)} / ${VodTimeFormatter.formatMs(dur)}")
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                userDraggingSeekBar = true
                uiHandler.removeCallbacks(hideControlsRunnable)
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                userDraggingSeekBar = false
                val dur = activeEngine.getDurationMs()
                if (dur > 0L && sb != null) {
                    val target = (dur * sb.progress.toLong()) / 10_000L
                    activeEngine.seekTo(target)
                }
                scheduleControlsAutoHide()
            }
        })

        vlcVideoLayout.setOnClickListener {
            if (!proController.isScreenLocked) {
                setControlsVisible(!controlsVisible)
            }
        }
    }

    private fun applySavedUiPreferences() {
        val interval = vodPrefs.getDefaultSeekInterval()
        seekController.setDefaultInterval(interval)
        btnRewind.text = "↺ ${interval.label}"
        btnForward.text = "${interval.label} ↻"
        btnSpeed.text = vodPrefs.getDefaultPlaybackSpeed().label
    }

    private fun startPayloadPlayback(data: VodLaunchPayload) {
        currentContentId = data.contentId
        currentStreamUrl = data.streamUrl
        currentTitle = data.title

        if (data.contentType == VodContentType.SERIES_EPISODE) {
            currentEpisode = data.episodes.firstOrNull { it.episodeId == data.contentId }
                ?: VodEpisodeNavItem(
                    episodeId = data.contentId,
                    seriesId = data.seriesId,
                    seriesKey = data.seriesKey,
                    seriesTitle = data.seriesTitle.ifBlank { data.title },
                    seasonNumber = data.seasonNumber.coerceAtLeast(1),
                    episodeNumber = data.episodeNumber.coerceAtLeast(1),
                    episodeTitle = data.title,
                    streamUrl = data.streamUrl,
                    posterUrl = data.posterUrl,
                    durationLabel = data.durationLabel,
                    containerExtension = data.containerExtension
                )
        } else {
            currentEpisode = null
        }

        updateHeaderAndSeriesControls(
            title = data.title,
            subtitle = data.subtitleLine.ifBlank {
                listOfNotNull(
                    data.category.takeIf { it.isNotBlank() },
                    data.releaseYear.takeIf { it.isNotBlank() },
                    data.containerExtension.uppercase(Locale.ROOT).takeIf { it.isNotBlank() }
                ).joinToString(" • ")
            }
        )

        activateSelectedEngine(VodEngineChoice.LIBVLC_PRIMARY, vodPrefs.getDecoderMode(), resolveAdaptiveBufferProfile())
        activeEngine.setPlaybackSpeed(vodPrefs.getDefaultPlaybackSpeed().rate)
        activeEngine.setAspectRatio(vodPrefs.getAspectRatioMode())
        activeEngine.setAudioDelayMs(vodPrefs.getAudioDelayMs())
        activeEngine.setSubtitleDelayMs(vodPrefs.getSubtitleDelayMs().toLong())
        activeEngine.applyDialoguePreset(vodPrefs.getDialoguePreset())

        val effectiveResumeMs = if (data.resumePositionMs > 0L) {
            data.resumePositionMs
        } else {
            progressStore.getResumePositionMs(
                contentId = data.contentId,
                accountScope = data.accountScope,
                resumeEnabled = vodPrefs.isResumePlaybackEnabled()
            )
        }

        startMediaStream(data.streamUrl, effectiveResumeMs, data.externalSubtitleUrl)
        uiHandler.removeCallbacks(progressTickRunnable)
        uiHandler.post(progressTickRunnable)
        uiHandler.removeCallbacks(periodicSaveRunnable)
        uiHandler.postDelayed(periodicSaveRunnable, 10_000L)
    }

    private fun updateHeaderAndSeriesControls(title: String, subtitle: String) {
        tvTitle.text = title
        tvSubtitleMeta.text = subtitle
        val isSeries = payload?.contentType == VodContentType.SERIES_EPISODE
        val hasPrev = isSeries && autoNextController.findPreviousEpisode(currentContentId) != null
        val hasNext = isSeries && autoNextController.findNextEpisode(currentContentId) != null
        btnPrevEpisode.visibility = if (hasPrev) View.VISIBLE else View.GONE
        btnNextEpisode.visibility = if (hasNext) View.VISIBLE else View.GONE
        btnEpisodes.visibility = if (isSeries && (payload?.episodes?.isNotEmpty() == true)) View.VISIBLE else View.GONE
    }

    private fun startMediaStream(streamUrl: String, resumePositionMs: Long, extSubUrl: String = "") {
        activeSessionToken = adaptiveBufferEngine.startNewSessionToken()
        diagnosticsEngine.resetForNewMedia()
        errorOverlay.visibility = View.GONE
        loadingContainer.visibility = View.VISIBLE
        preferredTracksApplied = false
        hideAutoNextCard()
        tvLoadingStatus.text = if (resumePositionMs > 10_000L) {
            "Resuming at ${VodTimeFormatter.formatMs(resumePositionMs)}..."
        } else {
            "Loading..."
        }
        tvStatusBadge.text = "LOADING"
        val ok = activeEngine.loadMedia(
            streamUrl = streamUrl,
            resumePositionMs = resumePositionMs,
            externalSubtitleUrl = extSubUrl
        )
        if (!ok) {
            showFatalError("Invalid Media URL", "This title does not have a valid playable stream address.", canRetry = false)
        }
    }

    private val engineCallbacks = object : VodEngineCallbacks {
        override fun onOpening() {
            if (recoveryController.isInitialLoad()) {
                loadingContainer.visibility = View.VISIBLE
                tvLoadingStatus.text = "Connecting..."
            }
            tvStatusBadge.text = "OPENING"
        }

        override fun onBuffering(percent: Float) {
            val pctInt = percent.toInt().coerceIn(0, 100)
            if (pctInt < 99) {
                diagnosticsEngine.onBufferingStarted()
                loadingContainer.visibility = View.VISIBLE
                tvLoadingStatus.text = if (recoveryController.isInitialLoad()) "Loading $pctInt%..." else "Buffering $pctInt%..."
                tvStatusBadge.text = "BUFFERING $pctInt%"
            } else {
                loadingContainer.visibility = View.GONE
            }
        }

        override fun onPlaying() {
            recoveryController.markPlaybackStarted()
            diagnosticsEngine.onBufferingEnded()
            val audioDiag = VodAudioDiagnosticsEngine.diagnose(activeEngine.getAudioTracks(), activeEngine.getAudioDelayMs(), vodPrefs.getDialoguePreset())
            if (audioDiag.status == VodAudioHealthStatus.AUDIO_TRACK_UNSELECTED && audioDiag.autoRecoverTrackId != null) {
                activeEngine.selectAudioTrack(audioDiag.autoRecoverTrackId)
            }
            loadingContainer.visibility = View.GONE
            errorOverlay.visibility = View.GONE
            btnPlayPause.text = "⏸"
            tvStatusBadge.text = "PLAYING"
            if (!preferredTracksApplied) {
                preferredTracksApplied = true
                audioController.applyPreferredAudioTrack(vlcEngine)
                if (!vodPrefs.isSubtitlesDefaultEnabled()) {
                    activeEngine.selectSubtitleTrack(-1)
                }
            }
            scheduleControlsAutoHide()
        }

        override fun onPaused() {
            btnPlayPause.text = "▶"
            tvStatusBadge.text = "PAUSED"
            saveCurrentPlaybackProgress()
        }

        override fun onTimeChanged(positionMs: Long) {
            // Handled cleanly by 500ms UI tick for smooth low-CPU TV rendering
        }

        override fun onLengthChanged(durationMs: Long) {
            updateTimelineFromEngine()
        }

        override fun onSeekableChanged(seekable: Boolean) {
            seekBar.isEnabled = seekable
        }

        override fun onTracksUpdated() {
            if (!preferredTracksApplied) {
                preferredTracksApplied = true
                audioController.applyPreferredAudioTrack(vlcEngine)
            }
        }

        override fun onEnded() {
            loadingContainer.visibility = View.GONE
            saveCurrentPlaybackProgress(forceCompleteIfEnded = true)
            btnPlayPause.text = "↻"
            tvStatusBadge.text = "COMPLETED"
            if (proController.shouldStopAtTitleEnd()) {
                proController.setSleepTimer(VodSleepTimerMode.OFF)
                setControlsVisible(true)
                Toast.makeText(this@VodPlayerActivity, "Sleep Timer: Stopped at end of title", Toast.LENGTH_LONG).show()
                return
            }
            val handled = checkAutoNextIfEligible(playbackEnded = true)
            if (!handled) setControlsVisible(true)
        }

        override fun onError(message: String) {
            saveCurrentPlaybackProgress()
            val decision = recoveryController.evaluateError(message, vodPrefs.getDecoderMode())
            when (decision.type) {
                VodRecoveryDecisionType.FALLBACK_SOFTWARE_DECODER -> {
                    loadingContainer.visibility = View.VISIBLE
                    tvLoadingStatus.text = decision.userTitle
                    val pos = activeEngine.getPositionMs().coerceAtLeast(0L)
                    uiHandler.postDelayed({
                        if (!isFinishing && !isDestroyed) {
                            activateSelectedEngine(engineCoordinator.getActiveChoice(), VodDecoderMode.SOFTWARE_ONLY, resolveAdaptiveBufferProfile())
                            startMediaStream(currentStreamUrl, pos)
                        }
                    }, decision.delayMs)
                }
                VodRecoveryDecisionType.RETRY_WITH_BACKOFF -> {
                    loadingContainer.visibility = View.VISIBLE
                    tvLoadingStatus.text = decision.userTitle
                    val pos = activeEngine.getPositionMs().coerceAtLeast(0L)
                    uiHandler.postDelayed({
                        if (!isFinishing && !isDestroyed) {
                            startMediaStream(currentStreamUrl, pos)
                        }
                    }, decision.delayMs)
                }
                VodRecoveryDecisionType.SHOW_FATAL_ERROR -> {
                    diagnosticsEngine.onErrorRecorded(message)
                    val fb = if (decision.canManualRetry) {
                        engineCoordinator.tryControlledFallback(vodPrefs.getDecoderMode(), resolveAdaptiveBufferProfile(), engineCallbacks)
                    } else null
                    if (fb != null) {
                        activeEngine = fb
                        bindActiveEngineSurface()
                        loadingContainer.visibility = View.VISIBLE
                        tvLoadingStatus.text = "Switching to ${fb.engineName}..."
                        startMediaStream(currentStreamUrl, activeEngine.getPositionMs())
                    } else {
                        showFatalError(decision.userTitle, decision.userMessage, decision.canManualRetry)
                    }
                }
            }
        }
    }

    private fun showFatalError(title: String, message: String, canRetry: Boolean) {
        loadingContainer.visibility = View.GONE
        hideAutoNextCard()
        setControlsVisible(false)
        tvErrorTitle.text = title
        tvErrorMessage.text = message
        btnErrorRetry.visibility = if (canRetry) View.VISIBLE else View.GONE
        errorOverlay.visibility = View.VISIBLE
        if (canRetry) btnErrorRetry.post { btnErrorRetry.requestFocus() }
        else btnErrorBack.post { btnErrorBack.requestFocus() }
    }

    private fun updateTimelineFromEngine() {
        val pos = activeEngine.getPositionMs().coerceAtLeast(0L)
        val dur = activeEngine.getDurationMs().coerceAtLeast(0L)
        val bufPct = activeEngine.getBufferedPercent().coerceIn(0f, 100f)

        if (!userDraggingSeekBar && !seekController.isContinuousScrubbing()) {
            tvCurrentTime.text = VodTimeFormatter.formatMs(pos)
            tvTotalDuration.text = if (dur > 0L) VodTimeFormatter.formatMs(dur) else "--:--"
            val remMs = if (dur > pos) dur - pos else 0L
            tvRemainingTime.text = if (dur > 0L) "-${VodTimeFormatter.formatMs(remMs)}" else ""
            if (dur > 0L) {
                seekBar.isEnabled = activeEngine.isSeekable()
                val prog = ((pos * 10_000L) / dur).toInt().coerceIn(0, 10_000)
                seekBar.progress = prog
                val secProg = (prog + (bufPct * 10f).toInt()).coerceIn(prog, 10_000)
                seekBar.secondaryProgress = secProg
            } else {
                seekBar.progress = 0
                seekBar.secondaryProgress = 0
            }
        }
    }

    private fun updateProFeaturesTick() {
        val pos = activeEngine.getPositionMs().coerceAtLeast(0L)
        val dur = activeEngine.getDurationMs().coerceAtLeast(0L)

        if (proController.shouldLoopBackToA(pos)) {
            activeEngine.seekTo(proController.loopPointAMs)
        }

        val showSkip = !proController.isScreenLocked &&
            loadingContainer.visibility != View.VISIBLE &&
            errorOverlay.visibility != View.VISIBLE &&
            autoNextCard.visibility != View.VISIBLE &&
            proController.isSkipIntroEligible(pos, dur)
        btnSkipIntro.visibility = if (showSkip) View.VISIBLE else View.GONE

        if (proController.isSleepTimerExpired()) {
            proController.setSleepTimer(VodSleepTimerMode.OFF)
            saveCurrentPlaybackProgress()
            activeEngine.pause()
            setControlsVisible(true)
            Toast.makeText(this, "Sleep Timer finished — Playback paused", Toast.LENGTH_LONG).show()
        }

        if (proController.isNerdStatsVisible) {
            val vi = activeEngine.getVideoInfo()
            val audLabel = activeEngine.getAudioTracks().firstOrNull { it.isSelected }?.name ?: "Default"
            tvNerdStatsHud.text = "ENGINE: ${activeEngine.engineName} (${vi.decoderModeLabel})\n" +
                proController.formatStatsHud(
                    videoWidth = vi.width,
                    videoHeight = vi.height,
                    videoFps = vi.fps,
                    videoCodec = vi.codec,
                    audioSummary = audLabel,
                    bitrateBps = vi.bitrateBps,
                    bufferedAheadMs = vodPrefs.getBufferProfile().networkCachingMs.toLong(),
                    speedLabel = vodPrefs.getDefaultPlaybackSpeed().label
                )
        }
    }

    private fun togglePlayPause() {
        if (activeEngine.isPlaying()) {
            activeEngine.pause()
        } else {
            activeEngine.play()
        }
    }

    private fun performStepSeek(isForward: Boolean) {
        val dur = activeEngine.getDurationMs()
        val preview = seekController.computeStepSeek(
            currentPositionMs = activeEngine.getPositionMs(),
            durationMs = dur,
            isSeekable = activeEngine.isSeekable(),
            isForward = isForward
        ) ?: return
        activeEngine.seekTo(preview.targetPositionMs)
        showFeedbackPill(
            primary = "${if (isForward) "↻" else "↺"} ${preview.formattedDelta()}",
            secondary = "${preview.formattedTarget()} / ${preview.formattedDuration()}"
        )
        updateTimelineFromEngine()
    }

    private fun performContinuousSeekStep(isForward: Boolean) {
        val dur = activeEngine.getDurationMs()
        val preview = seekController.onContinuousSeekStep(
            currentPositionMs = activeEngine.getPositionMs(),
            durationMs = dur,
            isSeekable = activeEngine.isSeekable(),
            isForward = isForward
        ) ?: return
        showFeedbackPill(
            primary = "${if (isForward) "↻" else "↺"} ${preview.formattedDelta()}",
            secondary = "${preview.formattedTarget()} / ${preview.formattedDuration()}"
        )
        tvCurrentTime.text = preview.formattedTarget()
        if (dur > 0L) {
            seekBar.progress = ((preview.targetPositionMs * 10_000L) / dur).toInt().coerceIn(0, 10_000)
        }
    }

    private fun commitContinuousSeek() {
        val target = seekController.commitContinuousSeek() ?: return
        activeEngine.seekTo(target)
        updateTimelineFromEngine()
    }

    private fun showFeedbackPill(primary: String, secondary: String) {
        tvSeekDelta.text = primary
        tvSeekTargetTime.text = secondary
        seekPreviewPill.visibility = View.VISIBLE
        uiHandler.removeCallbacks(hideSeekPreviewRunnable)
        uiHandler.postDelayed(hideSeekPreviewRunnable, 1_400L)
    }

    private fun checkAutoNextIfEligible(playbackEnded: Boolean = false): Boolean {
        val data = payload ?: return false
        if (data.contentType != VodContentType.SERIES_EPISODE) return false
        val nextEp = autoNextController.evaluateAutoNextTrigger(
            contentType = data.contentType,
            currentEpisodeId = currentContentId,
            positionMs = activeEngine.getPositionMs(),
            durationMs = activeEngine.getDurationMs(),
            playbackEnded = playbackEnded,
            autoNextEnabled = vodPrefs.isAutoNextEpisodeEnabled()
        ) ?: return false

        pendingAutoNextEpisode = nextEp
        autoNextTotalSec = vodPrefs.getAutoNextCountdownSec()
        autoNextRemainingSec = autoNextTotalSec
        tvAutoNextTitle.text = "${nextEp.seasonEpisodeBadge()} • ${nextEp.episodeTitle}"
        autoNextCard.visibility = View.VISIBLE
        btnAutoNextPlayNow.post { btnAutoNextPlayNow.requestFocus() }
        uiHandler.removeCallbacks(autoNextTickRunnable)
        uiHandler.post(autoNextTickRunnable)
        return true
    }

    private fun hideAutoNextCard() {
        uiHandler.removeCallbacks(autoNextTickRunnable)
        pendingAutoNextEpisode = null
        autoNextCard.visibility = View.GONE
    }

    private fun switchToEpisode(ep: VodEpisodeNavItem, resumePositionMs: Long) {
        saveCurrentPlaybackProgress()
        hideAutoNextCard()
        proController.clearAbLoop()
        recoveryController.resetForNewMedia()
        currentEpisode = ep
        currentContentId = ep.episodeId
        currentStreamUrl = ep.streamUrl
        currentTitle = "${ep.seriesTitle} • ${ep.seasonEpisodeBadge()} ${ep.episodeTitle}"
        autoNextController.resetForEpisode(ep.episodeId)

        updateHeaderAndSeriesControls(
            title = currentTitle,
            subtitle = "Season ${ep.seasonNumber}, Episode ${ep.episodeNumber}" +
                if (ep.durationLabel.isNotBlank()) " • ${ep.durationLabel}" else ""
        )

        val effectiveResume = if (resumePositionMs > 0L) {
            resumePositionMs
        } else {
            progressStore.getResumePositionMs(
                contentId = ep.episodeId,
                accountScope = payload?.accountScope ?: "default",
                resumeEnabled = vodPrefs.isResumePlaybackEnabled()
            )
        }
        startMediaStream(ep.streamUrl, effectiveResume)
    }

    // =========================================================================
    // NEXT-GEN AUDIO, SUBTITLE, VIDEO, SPEED, EPISODES, CINEMA TOOLS & SETTINGS PANELS
    // =========================================================================

    private fun showAudioPanelDialog() {
        val rows = ArrayList<PanelRow>()
        val tracks = activeEngine.getAudioTracks()
        if (tracks.isEmpty()) {
            rows.add(PanelRow("Default Audio Track", "Single audio stream active", "ACTIVE", true) {})
        } else {
            for (t in tracks) {
                rows.add(
                    PanelRow(
                        title = t.name,
                        subtitle = if (t.isOffOption) "Mute audio track" else "LibVLC multi-codec audio track",
                        badge = if (t.isSelected) "ACTIVE" else "SELECT",
                        selected = t.isSelected
                    ) {
                        activeEngine.selectAudioTrack(t.id)
                        if (!t.isOffOption) vodPrefs.setPreferredAudioLanguage(t.name.take(12))
                        Toast.makeText(this, "Audio: ${t.name}", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
        val curPreset = vodPrefs.getDialoguePreset()
        rows.add(
            PanelRow(
                title = "Cinema Audio: ${curPreset.label}",
                subtitle = "Cycle Normal / Voice Clarity / Cinema Dialogue Boost / Night Whisper (LibVLC Equalizer)",
                badge = "${curPreset.volumePercent}%",
                selected = curPreset != VodDialoguePreset.NORMAL
            ) {
                val next = audioController.cycleDialoguePreset(vlcEngine)
                vodPrefs.setDialoguePreset(next)
                Toast.makeText(this, "Cinema Audio: ${next.label}", Toast.LENGTH_SHORT).show()
            }
        )
        val curDelay = activeEngine.getAudioDelayMs()
        rows.add(
            PanelRow(
                title = "Audio Sync Delay: ${audioController.formatAudioDelayLabel(curDelay)}",
                subtitle = "Add +100ms (use -100ms row below for negative sync)",
                badge = "+100ms",
                selected = curDelay != 0L
            ) {
                val next = audioController.adjustAudioDelayMs(vlcEngine, 100L)
                vodPrefs.setAudioDelayMs(next)
                Toast.makeText(this, "Audio Sync: ${audioController.formatAudioDelayLabel(next)}", Toast.LENGTH_SHORT).show()
            }
        )
        rows.add(
            PanelRow(
                title = "Audio Sync Earlier (-100 ms)",
                subtitle = "Native negative audio delay (Lip-sync fix)",
                badge = "-100ms",
                selected = false
            ) {
                val next = audioController.adjustAudioDelayMs(vlcEngine, -100L)
                vodPrefs.setAudioDelayMs(next)
                Toast.makeText(this, "Audio Sync: ${audioController.formatAudioDelayLabel(next)}", Toast.LENGTH_SHORT).show()
            }
        )
        rows.add(
            PanelRow(
                title = "Reset Audio Sync to 0 ms",
                subtitle = "Restore default lip synchronization",
                badge = "RESET",
                selected = false
            ) {
                audioController.resetAudioDelay(vlcEngine)
                vodPrefs.setAudioDelayMs(0L)
                Toast.makeText(this, "Audio Sync reset to 0 ms", Toast.LENGTH_SHORT).show()
            }
        )
        presentMinimalPanel("Audio & Cinema Sound", "LibVLC multi-codec audio, Equalizer & ±Sync", rows)
    }

    private fun showSubtitlePanelDialog() {
        val rows = ArrayList<PanelRow>()
        val tracks = activeEngine.getSubtitleTracks()
        for (t in tracks) {
            rows.add(
                PanelRow(
                    title = t.name,
                    subtitle = if (t.isOffOption) "Disable subtitles" else "Embedded / External subtitle track",
                    badge = if (t.isSelected) "ACTIVE" else "SELECT",
                    selected = t.isSelected
                ) {
                    activeEngine.selectSubtitleTrack(t.id)
                    vodPrefs.setSubtitlesDefaultEnabled(!t.isOffOption)
                    if (!t.isOffOption) vodPrefs.setPreferredSubtitleLanguage(t.name.take(12))
                    Toast.makeText(this, "Subtitles: ${t.name}", Toast.LENGTH_SHORT).show()
                }
            )
        }
        val curDelay = activeEngine.getSubtitleDelayMs()
        rows.add(
            PanelRow(
                title = "Subtitle Sync Later (+250 ms) — Now: ${curDelay} ms",
                subtitle = "Native LibVLC subtitle delay adjustment",
                badge = "+250ms",
                selected = curDelay > 0L
            ) {
                val next = (curDelay + 250L).coerceIn(-5000L, 5000L)
                activeEngine.setSubtitleDelayMs(next)
                vodPrefs.setSubtitleDelayMs(next.toInt())
                Toast.makeText(this, "Subtitle Delay: ${next} ms", Toast.LENGTH_SHORT).show()
            }
        )
        rows.add(
            PanelRow(
                title = "Subtitle Sync Earlier (-250 ms)",
                subtitle = "Native negative subtitle offset",
                badge = "-250ms",
                selected = curDelay < 0L
            ) {
                val next = (curDelay - 250L).coerceIn(-5000L, 5000L)
                activeEngine.setSubtitleDelayMs(next)
                vodPrefs.setSubtitleDelayMs(next.toInt())
                Toast.makeText(this, "Subtitle Delay: ${next} ms", Toast.LENGTH_SHORT).show()
            }
        )
        rows.add(
            PanelRow(
                title = "Reset Subtitle Delay (0 ms)",
                subtitle = "Restore exact subtitle timing",
                badge = "RESET",
                selected = false
            ) {
                activeEngine.setSubtitleDelayMs(0L)
                vodPrefs.setSubtitleDelayMs(0)
                Toast.makeText(this, "Subtitle Delay reset to 0 ms", Toast.LENGTH_SHORT).show()
            }
        )
        presentMinimalPanel("Subtitles & Sync", "Embedded & external subtitles with ±delay", rows)
    }

    private fun showVideoSettingsDialog() {
        val vi = activeEngine.getVideoInfo()
        val rows = ArrayList<PanelRow>()
        val videoTracks = activeEngine.getVideoTracks()
        if (videoTracks.size > 1) {
            for (vt in videoTracks) {
                rows.add(
                    PanelRow(
                        title = vt.name,
                        subtitle = "Available stream video track",
                        badge = if (vt.isSelected) "ACTIVE" else "SELECT",
                        selected = vt.isSelected
                    ) {
                        activeEngine.selectVideoTrack(vt.id)
                        Toast.makeText(this, "Video Track: ${vt.name}", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        } else {
            val infoLine = if (vi.height > 0) {
                "Source: ${vi.width}×${vi.height} (${vi.resolutionLabel()}) • Codec: ${vi.codec}"
            } else {
                "Single fixed video stream from provider"
            }
            rows.add(PanelRow("Stream Quality: ${vi.resolutionLabel()}", infoLine, "SOURCE", true) {})
        }

        val curAspect = vodPrefs.getAspectRatioMode()
        rows.add(
            PanelRow(
                title = "Aspect Ratio: ${curAspect.label}",
                subtitle = "Cycle Fit / Fill / Zoom / Stretch / Original",
                badge = curAspect.label,
                selected = false
            ) {
                val next = curAspect.next()
                vodPrefs.setAspectRatioMode(next)
                activeEngine.setAspectRatio(next)
                Toast.makeText(this, "Aspect Ratio: ${next.label}", Toast.LENGTH_SHORT).show()
            }
        )

        val curDec = vodPrefs.getDecoderMode()
        rows.add(
            PanelRow(
                title = "Decoder: ${curDec.label}",
                subtitle = curDec.description,
                badge = curDec.id,
                selected = false
            ) {
                val next = curDec.next()
                vodPrefs.setDecoderMode(next)
                val pos = activeEngine.getPositionMs()
                activateSelectedEngine(engineCoordinator.getActiveChoice(), next, resolveAdaptiveBufferProfile())
                startMediaStream(currentStreamUrl, pos)
                Toast.makeText(this, "Decoder switched to ${next.label}", Toast.LENGTH_SHORT).show()
            }
        )

        val curBuf = vodPrefs.getBufferProfile()
        rows.add(
            PanelRow(
                title = "Anti-Buffer Cushion: ${curBuf.label}",
                subtitle = "Cycle 2.5s (Low-RAM) / 5.0s (Balanced) / 10.0s (Ultra Anti-Buffer)",
                badge = "${curBuf.networkCachingMs / 1000}s",
                selected = false
            ) {
                val next = curBuf.next()
                vodPrefs.setBufferProfile(next)
                val pos = activeEngine.getPositionMs()
                activateSelectedEngine(engineCoordinator.getActiveChoice(), vodPrefs.getDecoderMode(), next)
                startMediaStream(currentStreamUrl, pos)
                Toast.makeText(this, "Buffer Cushion: ${next.label}", Toast.LENGTH_SHORT).show()
            }
        )
        val curChoice = engineCoordinator.getActiveChoice()
        rows.add(
            PanelRow(
                title = "Playback Engine: ${curChoice.label}",
                subtitle = "Switch between LibVLC 3.6.5 (Primary) and Media3 1.11.1 (Fallback)",
                badge = "SWITCH",
                selected = false
            ) {
                val nextChoice = curChoice.opposite()
                val pos = activeEngine.getPositionMs()
                activateSelectedEngine(nextChoice, vodPrefs.getDecoderMode(), resolveAdaptiveBufferProfile())
                startMediaStream(currentStreamUrl, pos)
                Toast.makeText(this, "Engine switched to ${nextChoice.label}", Toast.LENGTH_SHORT).show()
            }
        )
        rows.add(
            PanelRow(
                title = "A/V Re-Sync Now",
                subtitle = "Re-align audio & video clocks at current timestamp without exiting",
                badge = "SYNC",
                selected = false
            ) {
                val pos = activeEngine.getPositionMs()
                activeEngine.seekTo(pos)
                Toast.makeText(this, "A/V clocks re-synchronized", Toast.LENGTH_SHORT).show()
            }
        )
        rows.add(
            PanelRow(
                title = "Full Playback & Audio Diagnostics",
                subtitle = "Inspect genuine codec, resolution, audio health, rebuffer count & seek accuracy",
                badge = "REPORT",
                selected = false
            ) {
                showFullDiagnosticsDialog()
            }
        )
        presentMinimalPanel("Video, Quality & Engine", "Active: ${activeEngine.engineName}", rows)
    }

    private fun showSpeedSelectorDialog() {
        val cur = vodPrefs.getDefaultPlaybackSpeed()
        val rows = VodPlaybackSpeed.values().map { sp ->
            PanelRow(
                title = "${sp.label} Speed",
                subtitle = if (sp == VodPlaybackSpeed.SPEED_1_0) "Standard cinema rate" else "Playback rate ${sp.label}",
                badge = if (sp == cur) "ACTIVE" else sp.label,
                selected = sp == cur
            ) {
                vodPrefs.setDefaultPlaybackSpeed(sp)
                activeEngine.setPlaybackSpeed(sp.rate)
                btnSpeed.text = sp.label
            }
        }
        presentMinimalPanel("Playback Speed", "0.5x – 2.0x precision pitch-preserved speed", rows)
    }

    private fun showCinemaToolsDialog() {
        val pos = activeEngine.getPositionMs()
        val dur = activeEngine.getDurationMs()
        val data = payload
        val inWatchlist = if (data != null) {
            if (data.contentType == VodContentType.SERIES_EPISODE && data.seriesKey.isNotBlank()) {
                profileStore.isSeriesInWatchlist(data.seriesKey, data.accountScope)
            } else {
                profileStore.isMovieInWatchlist(data.contentId, data.accountScope)
            }
        } else false

        val rows = listOf(
            PanelRow("Quick Jump & Chapters", "Jump -5m / +5m / 25% / 50% / 75% or Skip Intro (+85s)", "JUMP", false) {
                showQuickJumpDialog()
            },
            PanelRow("Micro-Replay (-3s)", "Instant 3-second replay for missed dialogue", "-3s", false) {
                val t = proController.computeMicroReplayTarget(pos)
                activeEngine.seekTo(t)
                showFeedbackPill("↺ -3s", VodTimeFormatter.formatMs(t))
            },
            PanelRow("A-B Scene Loop: ${proController.abLoopBadgeLabel()}", "Tap to set A, tap again to set B & repeat scene", "LOOP", proController.abLoopState != VodAbLoopState.OFF) {
                val st = proController.advanceAbLoop(activeEngine.getPositionMs())
                Toast.makeText(this, "A-B Loop: $st", Toast.LENGTH_SHORT).show()
            },
            PanelRow("Scene Bookmarks (${proController.getBookmarks().size})", "Save current timestamp or jump to saved scenes", "MARKS", false) {
                showSceneBookmarksDialog()
            },
            PanelRow("Picture Mode: ${proController.pictureMode.label}", "Cycle Standard / Warm Cinema / Cool Crisp / Eye Comfort", "COLOR", proController.pictureMode != VodPictureMode.STANDARD) {
                val m = proController.cyclePictureMode()
                colorTintOverlay.setBackgroundColor(m.tintColor)
                colorTintOverlay.alpha = m.tintAlpha
                Toast.makeText(this, "Picture Mode: ${m.label}", Toast.LENGTH_SHORT).show()
            },
            PanelRow("Night Dimmer: ${proController.nightDimLevel.label}", "Cycle Normal / Night Soft / Night Deep", "NIGHT", proController.nightDimLevel != VodNightDimLevel.OFF) {
                val lv = proController.cycleNightDim()
                nightDimOverlay.alpha = lv.overlayAlpha
                Toast.makeText(this, "Night Dimmer: ${lv.label}", Toast.LENGTH_SHORT).show()
            },
            PanelRow("VOD Sleep Timer: ${proController.sleepTimerMode.label}", "Cycle Off / 15m / 30m / 45m / 60m / End of Title", "SLEEP", proController.sleepTimerMode != VodSleepTimerMode.OFF) {
                val sm = proController.cycleSleepTimer()
                Toast.makeText(this, "Sleep Timer: ${sm.label}", Toast.LENGTH_SHORT).show()
            },
            PanelRow("Screen Lock (Kids Lock)", "Lock remote keys while watching; OK unlocks", "LOCK", false) {
                proController.toggleScreenLock()
                setControlsVisible(false)
                btnSkipIntro.visibility = View.GONE
                btnUnlockScreen.visibility = View.VISIBLE
                btnUnlockScreen.post { btnUnlockScreen.requestFocus() }
            },
            PanelRow("Diagnostics / Nerd Stats: ${if (proController.isNerdStatsVisible) "ON" else "OFF"}", "Show real-time codec, resolution, FPS & buffer HUD", "STATS", proController.isNerdStatsVisible) {
                val v = proController.toggleNerdStats()
                tvNerdStatsHud.visibility = if (v) View.VISIBLE else View.GONE
                updateProFeaturesTick()
            },
            PanelRow(if (inWatchlist) "★ Remove from Watchlist" else "☆ Add to Watchlist", "Save this title to your Movies/Series Watchlist", "LIST", inWatchlist) {
                if (data != null) {
                    val added = if (data.contentType == VodContentType.SERIES_EPISODE && data.seriesKey.isNotBlank()) {
                        profileStore.toggleSeriesWatchlist(data.seriesKey, ContentSourceType.XTREAM_SERIES, data.accountScope)
                    } else {
                        profileStore.toggleMovieWatchlist(data.contentId, ContentSourceType.XTREAM_VOD_MOVIE, data.accountScope)
                    }
                    Toast.makeText(this, if (added) "Added to Watchlist" else "Removed from Watchlist", Toast.LENGTH_SHORT).show()
                }
            }
        )
        presentMinimalPanel("Cinema Tools", "Pro playback utilities (${VodTimeFormatter.formatMs(pos)} / ${VodTimeFormatter.formatMs(dur)})", rows)
    }

    private fun showQuickJumpDialog() {
        val pos = activeEngine.getPositionMs()
        val dur = activeEngine.getDurationMs()
        val rows = listOf(
            PanelRow("Skip Intro (+85s)", "Jump forward 85 seconds", "+85s", false) {
                activeEngine.seekTo(proController.computeSkipIntroTarget(pos, dur))
            },
            PanelRow("Back 5 Minutes", "Rewind 5:00", "-5m", false) {
                activeEngine.seekTo(proController.computeMinuteJumpTarget(pos, dur, -5))
            },
            PanelRow("Forward 5 Minutes", "Advance 5:00", "+5m", false) {
                activeEngine.seekTo(proController.computeMinuteJumpTarget(pos, dur, 5))
            },
            PanelRow("Restart (0%)", "Jump to 00:00", "0%", false) { activeEngine.seekTo(0L) },
            PanelRow("Jump to 25%", if (dur > 0L) VodTimeFormatter.formatMs(proController.computePercentJumpTarget(dur, 25)) else "", "25%", false) {
                if (dur > 0L) activeEngine.seekTo(proController.computePercentJumpTarget(dur, 25))
            },
            PanelRow("Jump to 50%", if (dur > 0L) VodTimeFormatter.formatMs(proController.computePercentJumpTarget(dur, 50)) else "", "50%", false) {
                if (dur > 0L) activeEngine.seekTo(proController.computePercentJumpTarget(dur, 50))
            },
            PanelRow("Jump to 75%", if (dur > 0L) VodTimeFormatter.formatMs(proController.computePercentJumpTarget(dur, 75)) else "", "75%", false) {
                if (dur > 0L) activeEngine.seekTo(proController.computePercentJumpTarget(dur, 75))
            }
        )
        presentMinimalPanel("Quick Jump", "Instant navigation across long titles", rows)
    }

    private fun showSceneBookmarksDialog() {
        val curPos = activeEngine.getPositionMs()
        val rows = ArrayList<PanelRow>()
        rows.add(
            PanelRow("Save Current Scene (${VodTimeFormatter.formatMs(curPos)})", "Bookmark this timestamp", "SAVE", true) {
                val bm = proController.addBookmark(curPos)
                Toast.makeText(this, "Saved ${bm.label}", Toast.LENGTH_SHORT).show()
            }
        )
        for (bm in proController.getBookmarks()) {
            rows.add(
                PanelRow(bm.label, "Jump to ${VodTimeFormatter.formatMs(bm.positionMs)}", "JUMP", false) {
                    activeEngine.seekTo(bm.positionMs)
                }
            )
        }
        presentMinimalPanel("Scene Bookmarks", "Jump back to saved moments", rows)
    }

    private fun showEpisodesDrawerDialog() {
        val data = payload ?: return
        if (data.episodes.isEmpty()) return
        val rows = data.episodes.map { ep ->
            val isCurrent = ep.episodeId == currentContentId
            val saved = progressStore.getProgressEntry(ep.episodeId, data.accountScope)
            val watched = progressStore.isCompleted(ep.episodeId, data.accountScope)
            val badge = when {
                isCurrent -> "PLAYING"
                saved != null && saved.isResumable() -> "${saved.progressPercent()}%"
                watched -> "WATCHED"
                else -> "PLAY"
            }
            PanelRow(
                title = "${ep.seasonEpisodeBadge()} • ${ep.episodeTitle}",
                subtitle = "Season ${ep.seasonNumber}, Episode ${ep.episodeNumber}" +
                    if (ep.durationLabel.isNotBlank()) " • ${ep.durationLabel}" else "",
                badge = badge,
                selected = isCurrent
            ) {
                if (!isCurrent) switchToEpisode(ep, 0L)
            }
        }
        presentMinimalPanel("${data.seriesTitle.ifBlank { "Series" }} — Episodes", "${data.episodes.size} episodes", rows)
    }

    private fun showVodSettingsDialog() {
        val curSeek = vodPrefs.getDefaultSeekInterval()
        val curAutoNext = vodPrefs.isAutoNextEpisodeEnabled()
        val curCountdown = vodPrefs.getAutoNextCountdownSec()
        val curResume = vodPrefs.isResumePlaybackEnabled()
        val curHideSec = (vodPrefs.getControlsAutoHideMs() / 1000L).toInt()

        val rows = listOf(
            PanelRow("Seek Interval: ${curSeek.label}", "Cycle 5s / 10s / 15s / 20s / 30s / 60s", curSeek.label, true) {
                val all = VodSeekInterval.values()
                val next = all[(curSeek.ordinal + 1) % all.size]
                vodPrefs.setDefaultSeekInterval(next)
                seekController.setDefaultInterval(next)
                btnRewind.text = "↺ ${next.label}"
                btnForward.text = "${next.label} ↻"
            },
            PanelRow("Auto-Next Episode: ${if (curAutoNext) "ON" else "OFF"}", "Queue next series episode automatically", if (curAutoNext) "ON" else "OFF", curAutoNext) {
                vodPrefs.setAutoNextEpisodeEnabled(!curAutoNext)
            },
            PanelRow("Auto-Next Countdown: ${curCountdown}s", "Cycle 5s / 8s / 10s / 15s / 20s", "${curCountdown}s", false) {
                val steps = listOf(5, 8, 10, 15, 20)
                val next = steps[(steps.indexOf(curCountdown).coerceAtLeast(0) + 1) % steps.size]
                vodPrefs.setAutoNextCountdownSec(next)
            },
            PanelRow("Auto-Resume Playback: ${if (curResume) "ON" else "OFF"}", "Restore saved watch position automatically", if (curResume) "ON" else "OFF", curResume) {
                vodPrefs.setResumePlaybackEnabled(!curResume)
            },
            PanelRow("Controls Auto-Hide: ${curHideSec}s", "Cycle 3s / 5s / 8s / 12s", "${curHideSec}s", false) {
                val steps = listOf(3_000L, 5_000L, 8_000L, 12_000L)
                val idx = steps.indexOfFirst { it == vodPrefs.getControlsAutoHideMs() }.coerceAtLeast(0)
                vodPrefs.setControlsAutoHideMs(steps[(idx + 1) % steps.size])
            }
        )
        presentMinimalPanel("VOD Player Settings", "Isolated from Live TV settings", rows)
    }

    private data class PanelRow(
        val title: String,
        val subtitle: String,
        val badge: String,
        val selected: Boolean,
        val onClick: () -> Unit
    )

    private fun presentMinimalPanel(title: String, subtitle: String, rows: List<PanelRow>) {
        lastFocusedViewBeforeModal = currentFocus
        activeDialog?.dismiss()
        uiHandler.removeCallbacks(hideControlsRunnable)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_cinema_v22_panel)
            setPadding(dp(20), dp(18), dp(20), dp(16))
        }

        root.addView(TextView(this).apply {
            text = title
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
        })
        if (subtitle.isNotBlank()) {
            root.addView(TextView(this).apply {
                text = subtitle
                textSize = 11.5f
                setTextColor(Color.parseColor("#A1A1AA"))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(3); bottomMargin = dp(12) }
            })
        }

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var firstFocus: View? = null

        for (row in rows) {
            val tvRowTitle = TextView(this).apply {
                text = row.title
                textSize = 13.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val tvRowSub = if (row.subtitle.isNotBlank()) {
                TextView(this).apply {
                    text = row.subtitle
                    textSize = 11f
                    setTextColor(Color.parseColor("#A1A1AA"))
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                }
            } else null
            val tvRowBadge = TextView(this).apply {
                text = row.badge
                textSize = 10.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (row.selected) Color.parseColor("#38BDF8") else Color.parseColor("#D4D4D8"))
                setPadding(dp(8), dp(3), dp(8), dp(3))
            }

            val itemView = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                setBackgroundResource(R.drawable.bg_cinema_v22_btn)
                setPadding(dp(14), dp(10), dp(14), dp(10))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6) }
                setOnFocusChangeListener { _, hasFocus ->
                    tvRowTitle.setTextColor(if (hasFocus) Color.parseColor("#09090B") else Color.WHITE)
                    tvRowSub?.setTextColor(if (hasFocus) Color.parseColor("#27272A") else Color.parseColor("#A1A1AA"))
                    tvRowBadge.setTextColor(if (hasFocus) Color.parseColor("#09090B") else if (row.selected) Color.parseColor("#38BDF8") else Color.parseColor("#D4D4D8"))
                }
                setOnClickListener {
                    activeDialog?.dismiss()
                    row.onClick()
                    scheduleControlsAutoHide()
                }
            }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            col.addView(tvRowTitle)
            if (tvRowSub != null) col.addView(tvRowSub)
            itemView.addView(col)
            itemView.addView(tvRowBadge)

            if (firstFocus == null || row.selected) firstFocus = itemView
            list.addView(itemView)
        }
        scroll.addView(list)
        root.addView(scroll)

        val maxScrollH = (resources.displayMetrics.heightPixels * 0.56f).toInt().coerceAtLeast(dp(180))
        scroll.post {
            if (scroll.height > maxScrollH) {
                scroll.layoutParams = (scroll.layoutParams as LinearLayout.LayoutParams).apply { height = maxScrollH }
            }
        }

        val dlg = AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
            .setView(root)
            .setCancelable(true)
            .create()
        dlg.setOnDismissListener {
            scheduleControlsAutoHide()
            if (controlsVisible) {
                (lastFocusedViewBeforeModal ?: btnPlayPause).post { (lastFocusedViewBeforeModal ?: btnPlayPause).requestFocus() }
            }
        }
        dlg.show()
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(dp(500).coerceAtMost((resources.displayMetrics.widthPixels * 0.84f).toInt()), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        activeDialog = dlg
        firstFocus?.post { firstFocus?.requestFocus() }
    }

    // =========================================================================
    // TV REMOTE & SYSTEM VOLUME HANDLING
    // =========================================================================

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (proController.isScreenLocked) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                btnUnlockScreen.performClick()
                return true
            }
            btnUnlockScreen.visibility = View.VISIBLE
            btnUnlockScreen.post { btnUnlockScreen.requestFocus() }
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            val (cur, max) = audioController.adjustSystemVolume(increase = keyCode == KeyEvent.KEYCODE_VOLUME_UP)
            val pct = (cur * 100) / max.coerceAtLeast(1)
            showFeedbackPill("Volume $pct%", "$cur / $max")
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_VOLUME_MUTE) {
            val muted = audioController.toggleMute()
            showFeedbackPill(if (muted) "Muted" else "Unmuted", "System Audio")
            return true
        }

        val action = remoteController.onKeyDown(
            keyCode = keyCode,
            repeatCount = event?.repeatCount ?: 0,
            controlsVisible = controlsVisible,
            sidePanelOpen = activeDialog?.isShowing == true,
            errorOverlayVisible = errorOverlay.visibility == View.VISIBLE,
            autoNextVisible = autoNextCard.visibility == View.VISIBLE,
            seekBarFocused = currentFocus === seekBar
        )
        return when (action) {
            VodRemoteAction.SHOW_CONTROLS_AND_FOCUS_PLAY -> { setControlsVisible(true); true }
            VodRemoteAction.HIDE_CONTROLS -> { setControlsVisible(false); true }
            VodRemoteAction.CLOSE_SIDE_PANEL -> { activeDialog?.dismiss(); true }
            VodRemoteAction.TOGGLE_PLAY_PAUSE -> { togglePlayPause(); setControlsVisible(true); true }
            VodRemoteAction.SEEK_REWIND_STEP -> { performStepSeek(isForward = false); scheduleControlsAutoHide(); true }
            VodRemoteAction.SEEK_FORWARD_STEP -> { performStepSeek(isForward = true); scheduleControlsAutoHide(); true }
            VodRemoteAction.SEEK_REWIND_CONTINUOUS -> { performContinuousSeekStep(isForward = false); true }
            VodRemoteAction.SEEK_FORWARD_CONTINUOUS -> { performContinuousSeekStep(isForward = true); true }
            VodRemoteAction.OPEN_SETTINGS_PANEL -> { showVodSettingsDialog(); true }
            VodRemoteAction.EXIT_VOD_PLAYER -> { exitToDetails(); true }
            VodRemoteAction.RESET_AUTO_HIDE_ONLY -> { scheduleControlsAutoHide(); super.onKeyDown(keyCode, event) }
            VodRemoteAction.COMMIT_CONTINUOUS_SEEK,
            VodRemoteAction.NONE -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (proController.isScreenLocked) return true
        val action = remoteController.onKeyUp(keyCode, seekController.isContinuousScrubbing())
        if (action == VodRemoteAction.COMMIT_CONTINUOUS_SEEK) {
            commitContinuousSeek()
            scheduleControlsAutoHide()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    private fun setControlsVisible(visible: Boolean) {
        if (proController.isScreenLocked && visible) return
        controlsVisible = visible
        controlsContainer.visibility = if (visible) View.VISIBLE else View.GONE
        if (visible) {
            btnPlayPause.post { btnPlayPause.requestFocus() }
            scheduleControlsAutoHide()
        } else {
            uiHandler.removeCallbacks(hideControlsRunnable)
        }
    }

    private fun scheduleControlsAutoHide() {
        uiHandler.removeCallbacks(hideControlsRunnable)
        if (controlsVisible) {
            uiHandler.postDelayed(hideControlsRunnable, vodPrefs.getControlsAutoHideMs())
        }
    }

    private fun saveCurrentPlaybackProgress(forceCompleteIfEnded: Boolean = false) {
        val data = payload ?: return
        val dur = activeEngine.getDurationMs()
        val pos = if (forceCompleteIfEnded && dur > 0L) dur else activeEngine.getPositionMs()
        val ep = currentEpisode
        progressStore.recordProgress(
            contentType = data.contentType,
            contentId = currentContentId,
            positionMs = pos,
            durationMs = dur,
            accountScope = data.accountScope,
            seriesKey = ep?.seriesKey ?: data.seriesKey,
            seasonNumber = ep?.seasonNumber ?: data.seasonNumber,
            episodeNumber = ep?.episodeNumber ?: data.episodeNumber
        )
    }

    private fun exitToDetails() {
        saveCurrentPlaybackProgress()
        val data = payload
        val resultIntent = Intent().apply {
            putExtra(VodPlayerLauncher.RESULT_RETURN_ACTION, VodPlayerLauncher.ACTION_BACK_TO_DETAILS)
            putExtra(VodPlayerLauncher.RESULT_LAST_CONTENT_ID, currentContentId)
            putExtra(VodPlayerLauncher.RESULT_LAST_SERIES_KEY, currentEpisode?.seriesKey ?: data?.seriesKey.orEmpty())
            putExtra(VodPlayerLauncher.RESULT_LAST_SEASON, currentEpisode?.seasonNumber ?: data?.seasonNumber ?: 1)
        }
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    private fun enableImmersiveFullscreen() {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.attributes = window.attributes.apply {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                window.attributes = window.attributes.apply {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            WindowCompat.setDecorFitsSystemWindows(window, false)
            val controller = WindowInsetsControllerCompat(window, window.decorView)
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enableImmersiveFullscreen()
    }

    override fun onPause() {
        super.onPause()
        saveCurrentPlaybackProgress()
        activeEngine.pause()
    }

    override fun onResume() {
        super.onResume()
        if (errorOverlay.visibility != View.VISIBLE && activeDialog?.isShowing != true) {
            activeEngine.play()
        }
    }

    override fun onStop() {
        super.onStop()
        saveCurrentPlaybackProgress()
        activeEngine.pause()
    }

    override fun onDestroy() {
        uiHandler.removeCallbacksAndMessages(null)
        activeDialog?.dismiss()
        activeDialog = null
        saveCurrentPlaybackProgress()
        adaptiveBufferEngine.cancelPendingSessions()
        engineCoordinator.releaseAll()
        super.onDestroy()
    }

    private fun activateSelectedEngine(
        choice: VodEngineChoice,
        decoderMode: VodDecoderMode,
        bufferProfile: VodBufferProfile
    ) {
        activeEngine = engineCoordinator.activate(choice, decoderMode, bufferProfile, engineCallbacks)
        bindActiveEngineSurface()
        activeEngine.setPlaybackSpeed(vodPrefs.getDefaultPlaybackSpeed().rate)
        activeEngine.setAspectRatio(vodPrefs.getAspectRatioMode())
        activeEngine.setAudioDelayMs(vodPrefs.getAudioDelayMs())
        activeEngine.setSubtitleDelayMs(vodPrefs.getSubtitleDelayMs().toLong())
        activeEngine.applyDialoguePreset(vodPrefs.getDialoguePreset())
    }

    private fun bindActiveEngineSurface() {
        val eng = activeEngine
        if (eng is LibVlcVodPlayerEngine) {
            fallbackPlayerView.visibility = View.GONE
            vlcVideoLayout.visibility = View.VISIBLE
            eng.attachVideoLayout(vlcVideoLayout)
        } else if (eng is Media3FallbackVodEngine) {
            vlcVideoLayout.visibility = View.GONE
            fallbackPlayerView.visibility = View.VISIBLE
            eng.attachPlayerView(fallbackPlayerView)
        }
    }

    private fun detectNetworkClass(): VodNetworkClass {
        return runCatching {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return VodNetworkClass.UNKNOWN
            val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return VodNetworkClass.OFFLINE
            when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> VodNetworkClass.ETHERNET
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> VodNetworkClass.WIFI
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> VodNetworkClass.CELLULAR
                else -> VodNetworkClass.UNKNOWN
            }
        }.getOrDefault(VodNetworkClass.UNKNOWN)
    }

    private fun resolveAdaptiveBufferProfile(): VodBufferProfile {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val mi = ActivityManager.MemoryInfo()
        val totalRamMb = if (am != null) {
            am.getMemoryInfo(mi)
            mi.totalMem / (1024L * 1024L)
        } else 2048L
        val isLowRam = am?.isLowRamDevice == true
        return adaptiveBufferEngine.recommendBufferProfile(
            userPreferred = vodPrefs.getBufferProfile(),
            totalRamMb = totalRamMb,
            isLowRamDevice = isLowRam,
            networkClass = detectNetworkClass(),
            recentRebufferCount = diagnosticsEngine.getBufferingEventCount()
        )
    }

    private fun showFullDiagnosticsDialog() {
        val vi = activeEngine.getVideoInfo()
        val snap = diagnosticsEngine.snapshot(activeEngine.engineName, vi, detectNetworkClass(), resolveAdaptiveBufferProfile())
        val audioDiag = VodAudioDiagnosticsEngine.diagnose(activeEngine.getAudioTracks(), activeEngine.getAudioDelayMs(), vodPrefs.getDialoguePreset(), snap.lastErrorRedacted)
        val rows = listOf(
            PanelRow("Active Engine: ${snap.engineName}", "Decoder: ${vi.decoderModeLabel} • Network: ${snap.networkClass.label}", "ENGINE", true) {},
            PanelRow("Video: ${vi.width}×${vi.height} (${vi.resolutionLabel()})", "Codec: ${vi.codec} • FPS: ${if (vi.fps > 0f) String.format(Locale.ROOT, "%.1f", vi.fps) else "N/A"} • Dropped: ${if (snap.droppedFramesReported >= 0) snap.droppedFramesReported else "N/A"}", "VIDEO", false) {},
            PanelRow("Audio Health: ${audioDiag.status.label}", "${audioDiag.selectedTrackName} (${audioDiag.totalAudioTracks} tracks) • Delay: ${audioDiag.audioDelayMs}ms • ${audioDiag.status.guidance}", "AUDIO", audioDiag.status == VodAudioHealthStatus.HEALTHY) {},
            PanelRow("Buffering & Recovery", "Events: ${snap.bufferingEvents} • Total: ${snap.totalBufferingMs}ms • Cushion: ${snap.activeBufferProfile.label} • Errors: ${snap.errorEvents}", "NET", false) {},
            PanelRow("Last Error (Redacted)", snap.lastErrorRedacted, "LOG", false) {}
        )
        presentMinimalPanel("Playback Diagnostics (v23.0)", "Genuine runtime telemetry — no simulated values", rows)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("v23_content_id", currentContentId)
        outState.putLong("v23_resume_pos", activeEngine.getPositionMs())
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics).toInt()
}
