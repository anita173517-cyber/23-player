package com.harindra.iptvpro.vod

import com.harindra.iptvpro.NetworkClient
import java.util.concurrent.atomic.AtomicLong

/**
 * RAM PLAYER v23.0 ADD-ON 4, 5, 6 & 9:
 * - Genuine Video & Playback Diagnostics (never invents fake metrics)
 * - Network-Aware & Device-Aware Adaptive Buffering (512MB TV RAM cap + rebuffer escalation)
 * - Session Token Guard (cancels obsolete retries & prevents duplicate playback sessions)
 * - Frame-Drop & Seek Accuracy Monitoring
 */
enum class VodNetworkClass(val label: String) {
    ETHERNET("Ethernet"),
    WIFI("Wi-Fi"),
    CELLULAR("Mobile Data"),
    OFFLINE("Offline"),
    UNKNOWN("Network")
}

data class VodDiagnosticsSnapshot(
    val engineName: String,
    val videoInfo: VodEngineVideoInfo,
    val bufferingEvents: Int,
    val totalBufferingMs: Long,
    val errorEvents: Int,
    val lastErrorRedacted: String,
    val lastSeekAccuracyDeltaMs: Long,
    val droppedFramesReported: Int, // -1 if engine does not expose dropped frames
    val networkClass: VodNetworkClass,
    val activeBufferProfile: VodBufferProfile
)

class VodDiagnosticsEngine {
    private var bufferingEvents: Int = 0
    private var totalBufferingMs: Long = 0L
    private var bufferingStartedAtMs: Long = 0L
    private var errorEvents: Int = 0
    private var lastErrorRedacted: String = "None"
    private var lastSeekAccuracyDeltaMs: Long = 0L
    private var droppedFramesReported: Int = -1

    fun resetForNewMedia() {
        bufferingEvents = 0
        totalBufferingMs = 0L
        bufferingStartedAtMs = 0L
        errorEvents = 0
        lastErrorRedacted = "None"
        lastSeekAccuracyDeltaMs = 0L
        droppedFramesReported = -1
    }

    fun onBufferingStarted(nowMs: Long = System.currentTimeMillis()) {
        if (bufferingStartedAtMs == 0L) {
            bufferingStartedAtMs = nowMs
            bufferingEvents++
        }
    }

    fun onBufferingEnded(nowMs: Long = System.currentTimeMillis()) {
        if (bufferingStartedAtMs > 0L) {
            totalBufferingMs += (nowMs - bufferingStartedAtMs).coerceAtLeast(0L)
            bufferingStartedAtMs = 0L
        }
    }

    fun onErrorRecorded(rawError: String) {
        errorEvents++
        lastErrorRedacted = NetworkClient.redactSensitiveUrl(rawError).ifBlank { "Playback error" }
    }

    fun recordSeekAccuracy(requestedMs: Long, actualMs: Long) {
        lastSeekAccuracyDeltaMs = kotlin.math.abs(actualMs - requestedMs)
    }

    fun updateDroppedFrames(count: Int) {
        droppedFramesReported = count
    }

    fun getBufferingEventCount(): Int = bufferingEvents

    fun getTotalBufferingMs(): Long = totalBufferingMs

    fun getErrorCount(): Int = errorEvents

    fun snapshot(
        engineName: String,
        videoInfo: VodEngineVideoInfo,
        networkClass: VodNetworkClass,
        bufferProfile: VodBufferProfile
    ): VodDiagnosticsSnapshot {
        return VodDiagnosticsSnapshot(
            engineName = engineName,
            videoInfo = videoInfo,
            bufferingEvents = bufferingEvents,
            totalBufferingMs = totalBufferingMs,
            errorEvents = errorEvents,
            lastErrorRedacted = lastErrorRedacted,
            lastSeekAccuracyDeltaMs = lastSeekAccuracyDeltaMs,
            droppedFramesReported = droppedFramesReported,
            networkClass = networkClass,
            activeBufferProfile = bufferProfile
        )
    }
}

class VodAdaptiveBufferEngine {
    private val sessionCounter = AtomicLong(0L)

    fun startNewSessionToken(): Long = sessionCounter.incrementAndGet()

    fun isSessionCurrent(token: Long): Boolean = sessionCounter.get() == token

    fun cancelPendingSessions() {
        sessionCounter.incrementAndGet()
    }

    /**
     * Computes a device-safe and network-aware VOD buffer profile.
     * Enforces strict 512MB/1GB low-RAM protection so low-memory TVs never OOM.
     */
    fun recommendBufferProfile(
        userPreferred: VodBufferProfile,
        totalRamMb: Long,
        isLowRamDevice: Boolean,
        networkClass: VodNetworkClass,
        recentRebufferCount: Int
    ): VodBufferProfile {
        if (isLowRamDevice || totalRamMb in 1L..1024L) {
            return VodBufferProfile.FAST_START
        }
        if (recentRebufferCount >= 3 && totalRamMb >= 2048L) {
            return VodBufferProfile.ULTRA_ANTI_BUFFER
        }
        if (networkClass == VodNetworkClass.CELLULAR && userPreferred == VodBufferProfile.ULTRA_ANTI_BUFFER) {
            return VodBufferProfile.CINEMA_BALANCED
        }
        return userPreferred
    }
}
