package com.harindra.iptvpro.vod

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * RAM PLAYER v23.0 ULTIMATE ENHANCEMENT ADD-ON — Automated Unit Tests.
 * Covers Multi-Engine Coordinator, Missing-Audio Diagnostics, Adaptive Buffering,
 * Session Token Cancellation, and Genuine Playback Diagnostics.
 */
class VodV23EnhancementTest {

    private class StubEngine(override val engineName: String) : VodPlayerEngine {
        var initCount = 0
        var releaseCount = 0
        override fun initialize(decoderMode: VodDecoderMode, bufferProfile: VodBufferProfile) { initCount++ }
        override fun setCallbacks(callbacks: VodEngineCallbacks?) {}
        override fun loadMedia(streamUrl: String, resumePositionMs: Long, externalSubtitleUrl: String, headers: Map<String, String>): Boolean = true
        override fun play() {}
        override fun pause() {}
        override fun stop() {}
        override fun isPlaying(): Boolean = false
        override fun isSeekable(): Boolean = true
        override fun getPositionMs(): Long = 0L
        override fun getDurationMs(): Long = 100_000L
        override fun getBufferedPercent(): Float = 100f
        override fun seekTo(positionMs: Long) {}
        override fun setPlaybackSpeed(rate: Float) {}
        override fun getPlaybackSpeed(): Float = 1.0f
        override fun setVolumePercent(percent: Int) {}
        override fun getVolumePercent(): Int = 100
        override fun setAudioDelayMs(delayMs: Long) {}
        override fun getAudioDelayMs(): Long = 0L
        override fun setSubtitleDelayMs(delayMs: Long) {}
        override fun getSubtitleDelayMs(): Long = 0L
        override fun getAudioTracks(): List<VodEngineTrack> = emptyList()
        override fun selectAudioTrack(trackId: Int): Boolean = false
        override fun getSubtitleTracks(): List<VodEngineTrack> = emptyList()
        override fun selectSubtitleTrack(trackId: Int): Boolean = false
        override fun addExternalSubtitle(subtitleUrl: String): Boolean = false
        override fun getVideoTracks(): List<VodEngineTrack> = emptyList()
        override fun selectVideoTrack(trackId: Int): Boolean = false
        override fun getVideoInfo(): VodEngineVideoInfo = VodEngineVideoInfo()
        override fun setAspectRatio(mode: VodAspectRatioMode) {}
        override fun applyDialoguePreset(preset: VodDialoguePreset) {}
        override fun release() { releaseCount++ }
    }

    @Test
    fun engineCoordinatorEnforcesSingleActiveDecoderAndControlledFallback() {
        val primary = StubEngine("LibVLC")
        val fallback = StubEngine("Media3")
        val coord = VodEngineCoordinator({ primary }, { fallback })

        val e1 = coord.activate(VodEngineChoice.LIBVLC_PRIMARY, VodDecoderMode.AUTO_HW_FALLBACK, VodBufferProfile.CINEMA_BALANCED, null)
        assertEquals("LibVLC", e1.engineName)
        assertEquals(1, primary.initCount)
        assertEquals(0, primary.releaseCount)

        // Controlled fallback MUST release primary BEFORE initializing fallback
        val e2 = coord.tryControlledFallback(VodDecoderMode.AUTO_HW_FALLBACK, VodBufferProfile.CINEMA_BALANCED, null)
        assertNotNull(e2)
        assertEquals("Media3", e2!!.engineName)
        assertEquals(1, primary.releaseCount)
        assertEquals(1, fallback.initCount)
        assertTrue(coord.hasFallenBack())

        // Second automatic fallback must NOT loop
        assertNull(coord.tryControlledFallback(VodDecoderMode.AUTO_HW_FALLBACK, VodBufferProfile.CINEMA_BALANCED, null))

        coord.releaseAll()
        assertEquals(1, fallback.releaseCount)
        assertNull(coord.getActiveEngine())
    }

    @Test
    fun audioDiagnosticsDetectsMissingUnselectedAndHealthyTracks() {
        val missing = VodAudioDiagnosticsEngine.diagnose(emptyList(), 0L, VodDialoguePreset.NORMAL)
        assertEquals(VodAudioHealthStatus.MISSING_AUDIO_TRACK, missing.status)

        val unselected = VodAudioDiagnosticsEngine.diagnose(
            listOf(VodEngineTrack(5, "Hindi AAC", isSelected = false)),
            0L,
            VodDialoguePreset.NORMAL
        )
        assertEquals(VodAudioHealthStatus.AUDIO_TRACK_UNSELECTED, unselected.status)
        assertEquals(5, unselected.autoRecoverTrackId)

        val healthy = VodAudioDiagnosticsEngine.diagnose(
            listOf(VodEngineTrack(5, "Hindi AAC", isSelected = true)),
            -100L,
            VodDialoguePreset.VOICE_CLARITY
        )
        assertEquals(VodAudioHealthStatus.HEALTHY, healthy.status)
        assertEquals("Hindi AAC", healthy.selectedTrackName)
    }

    @Test
    fun adaptiveBufferEngineEnforcesLowRamCapAndCancelsStaleSessions() {
        val engine = VodAdaptiveBufferEngine()
        val t1 = engine.startNewSessionToken()
        assertTrue(engine.isSessionCurrent(t1))
        val t2 = engine.startNewSessionToken()
        assertFalse(engine.isSessionCurrent(t1))
        assertTrue(engine.isSessionCurrent(t2))

        // 512MB/1GB low-RAM TV MUST stay capped at FAST_START
        assertEquals(
            VodBufferProfile.FAST_START,
            engine.recommendBufferProfile(VodBufferProfile.ULTRA_ANTI_BUFFER, 512L, true, VodNetworkClass.WIFI, 5)
        )
        // 2GB+ TV with 3+ rebuffers escalates to ULTRA_ANTI_BUFFER
        assertEquals(
            VodBufferProfile.ULTRA_ANTI_BUFFER,
            engine.recommendBufferProfile(VodBufferProfile.CINEMA_BALANCED, 2048L, false, VodNetworkClass.WIFI, 3)
        )
    }

    @Test
    fun diagnosticsEngineTracksGenuineBufferingAndSeekAccuracy() {
        val diag = VodDiagnosticsEngine()
        diag.onBufferingStarted(1000L)
        diag.onBufferingEnded(2600L)
        diag.recordSeekAccuracy(60_000L, 60_350L)
        diag.onErrorRecorded("HTTP error on http://user:secret@host/movie/u/p/123.mp4")

        val snap = diag.snapshot("LibVLC 3.6.5", VodEngineVideoInfo(1920, 1080, 24f, "H264", 3_000_000, "HW"), VodNetworkClass.WIFI, VodBufferProfile.CINEMA_BALANCED)
        assertEquals(1, snap.bufferingEvents)
        assertEquals(1600L, snap.totalBufferingMs)
        assertEquals(350L, snap.lastSeekAccuracyDeltaMs)
        assertEquals(1, snap.errorEvents)
        assertFalse(snap.lastErrorRedacted.contains("secret"))
    }
}
